--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.8 (a48d9ca)
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE neondb;
--
-- Name: neondb; Type: DATABASE; Schema: -; Owner: neondb_owner
--

CREATE DATABASE neondb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = builtin LOCALE = 'C.UTF-8' BUILTIN_LOCALE = 'C.UTF-8';


ALTER DATABASE neondb OWNER TO neondb_owner;

\unrestrict (null)
\connect neondb
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: neondb_owner
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO neondb_owner;

--
-- Name: patients; Type: SCHEMA; Schema: -; Owner: neondb_owner
--

CREATE SCHEMA patients;


ALTER SCHEMA patients OWNER TO neondb_owner;

--
-- Name: ventas; Type: SCHEMA; Schema: -; Owner: neondb_owner
--

CREATE SCHEMA ventas;


ALTER SCHEMA ventas OWNER TO neondb_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tblappointments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tblappointments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    scheduled_at timestamp with time zone NOT NULL,
    status character varying DEFAULT 'pending'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.tblappointments OWNER TO neondb_owner;

--
-- Name: tblappointments_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tblappointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tblappointments_id_seq OWNER TO neondb_owner;

--
-- Name: tblappointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tblappointments_id_seq OWNED BY public.tblappointments.id;


--
-- Name: tblauditoria; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tblauditoria (
    id integer NOT NULL,
    usuario character varying(100) NOT NULL,
    accion character varying(50) NOT NULL,
    tabla_afectada character varying(100) NOT NULL,
    query_text text,
    datos_anteriores jsonb,
    datos_nuevos jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tblauditoria OWNER TO neondb_owner;

--
-- Name: tblauditoria_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tblauditoria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tblauditoria_id_seq OWNER TO neondb_owner;

--
-- Name: tblauditoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tblauditoria_id_seq OWNED BY public.tblauditoria.id;


--
-- Name: tblcart_items; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tblcart_items (
    id integer NOT NULL,
    cart_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer DEFAULT 1,
    subtotal numeric
);


ALTER TABLE public.tblcart_items OWNER TO neondb_owner;

--
-- Name: tblcart_items_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tblcart_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tblcart_items_id_seq OWNER TO neondb_owner;

--
-- Name: tblcart_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tblcart_items_id_seq OWNED BY public.tblcart_items.id;


--
-- Name: tblcarts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tblcarts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    status character varying,
    total numeric,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.tblcarts OWNER TO neondb_owner;

--
-- Name: tblcarts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tblcarts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tblcarts_id_seq OWNER TO neondb_owner;

--
-- Name: tblcarts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tblcarts_id_seq OWNED BY public.tblcarts.id;


--
-- Name: tblcategories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tblcategories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.tblcategories OWNER TO neondb_owner;

--
-- Name: tblcategorias_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tblcategorias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tblcategorias_id_seq OWNER TO neondb_owner;

--
-- Name: tblcategorias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tblcategorias_id_seq OWNED BY public.tblcategories.id;


--
-- Name: tblconsultations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tblconsultations (
    id integer NOT NULL,
    patient_id integer NOT NULL,
    weight numeric,
    height numeric,
    imc numeric,
    diagnosis text,
    recommendations text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.tblconsultations OWNER TO neondb_owner;

--
-- Name: tblconsultations_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tblconsultations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tblconsultations_id_seq OWNER TO neondb_owner;

--
-- Name: tblconsultations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tblconsultations_id_seq OWNED BY public.tblconsultations.id;


--
-- Name: tblpatients; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tblpatients (
    id integer NOT NULL,
    user_id integer NOT NULL,
    first_name character varying NOT NULL,
    second_name character varying,
    first_lastname character varying NOT NULL,
    second_lastname character varying,
    age integer,
    gender character varying,
    phone character varying,
    notes text,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.tblpatients OWNER TO neondb_owner;

--
-- Name: tblpatients_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tblpatients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tblpatients_id_seq OWNER TO neondb_owner;

--
-- Name: tblpatients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tblpatients_id_seq OWNED BY public.tblpatients.id;


--
-- Name: tblproducts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tblproducts (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    image_url text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    active boolean DEFAULT true NOT NULL,
    CONSTRAINT tblproducts_price_check CHECK ((price >= (0)::numeric)),
    CONSTRAINT tblproducts_stock_check CHECK ((stock >= 0))
);


ALTER TABLE public.tblproducts OWNER TO neondb_owner;

--
-- Name: tblproducts_categories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tblproducts_categories (
    product_id integer NOT NULL,
    category_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tblproducts_categories OWNER TO neondb_owner;

--
-- Name: tblproducts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tblproducts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tblproducts_id_seq OWNER TO neondb_owner;

--
-- Name: tblproducts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tblproducts_id_seq OWNED BY public.tblproducts.id;


--
-- Name: tblroles; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tblroles (
    id integer NOT NULL,
    rol character varying(20) NOT NULL
);


ALTER TABLE public.tblroles OWNER TO neondb_owner;

--
-- Name: tblroles_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tblroles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tblroles_id_seq OWNER TO neondb_owner;

--
-- Name: tblroles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tblroles_id_seq OWNED BY public.tblroles.id;


--
-- Name: tblusers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tblusers (
    id integer NOT NULL,
    rol_id integer,
    username character varying(64) NOT NULL,
    email character varying(128) NOT NULL,
    password_hash text NOT NULL,
    code character varying(6),
    expiracion timestamp without time zone,
    recovery_token character varying(256),
    recovery_exp timestamp without time zone,
    verified boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tblusers OWNER TO neondb_owner;

--
-- Name: tblusers_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tblusers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tblusers_id_seq OWNER TO neondb_owner;

--
-- Name: tblusers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tblusers_id_seq OWNED BY public.tblusers.id;


--
-- Name: tblappointments id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblappointments ALTER COLUMN id SET DEFAULT nextval('public.tblappointments_id_seq'::regclass);


--
-- Name: tblauditoria id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblauditoria ALTER COLUMN id SET DEFAULT nextval('public.tblauditoria_id_seq'::regclass);


--
-- Name: tblcart_items id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblcart_items ALTER COLUMN id SET DEFAULT nextval('public.tblcart_items_id_seq'::regclass);


--
-- Name: tblcarts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblcarts ALTER COLUMN id SET DEFAULT nextval('public.tblcarts_id_seq'::regclass);


--
-- Name: tblcategories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblcategories ALTER COLUMN id SET DEFAULT nextval('public.tblcategorias_id_seq'::regclass);


--
-- Name: tblconsultations id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblconsultations ALTER COLUMN id SET DEFAULT nextval('public.tblconsultations_id_seq'::regclass);


--
-- Name: tblpatients id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblpatients ALTER COLUMN id SET DEFAULT nextval('public.tblpatients_id_seq'::regclass);


--
-- Name: tblproducts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblproducts ALTER COLUMN id SET DEFAULT nextval('public.tblproducts_id_seq'::regclass);


--
-- Name: tblroles id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblroles ALTER COLUMN id SET DEFAULT nextval('public.tblroles_id_seq'::regclass);


--
-- Name: tblusers id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblusers ALTER COLUMN id SET DEFAULT nextval('public.tblusers_id_seq'::regclass);


--
-- Data for Name: tblappointments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tblappointments (id, user_id, scheduled_at, status, notes, created_at, updated_at) FROM stdin;
\.
COPY public.tblappointments (id, user_id, scheduled_at, status, notes, created_at, updated_at) FROM '$$PATH$$/3477.dat';

--
-- Data for Name: tblauditoria; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tblauditoria (id, usuario, accion, tabla_afectada, query_text, datos_anteriores, datos_nuevos, created_at) FROM stdin;
\.
COPY public.tblauditoria (id, usuario, accion, tabla_afectada, query_text, datos_anteriores, datos_nuevos, created_at) FROM '$$PATH$$/3483.dat';

--
-- Data for Name: tblcart_items; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tblcart_items (id, cart_id, product_id, quantity, subtotal) FROM stdin;
\.
COPY public.tblcart_items (id, cart_id, product_id, quantity, subtotal) FROM '$$PATH$$/3481.dat';

--
-- Data for Name: tblcarts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tblcarts (id, user_id, status, total, created_at, updated_at) FROM stdin;
\.
COPY public.tblcarts (id, user_id, status, total, created_at, updated_at) FROM '$$PATH$$/3479.dat';

--
-- Data for Name: tblcategories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tblcategories (id, name, description, created_at, updated_at, active) FROM stdin;
\.
COPY public.tblcategories (id, name, description, created_at, updated_at, active) FROM '$$PATH$$/3464.dat';

--
-- Data for Name: tblconsultations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tblconsultations (id, patient_id, weight, height, imc, diagnosis, recommendations, created_at, updated_at) FROM stdin;
\.
COPY public.tblconsultations (id, patient_id, weight, height, imc, diagnosis, recommendations, created_at, updated_at) FROM '$$PATH$$/3475.dat';

--
-- Data for Name: tblpatients; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tblpatients (id, user_id, first_name, second_name, first_lastname, second_lastname, age, gender, phone, notes, active, created_at, updated_at) FROM stdin;
\.
COPY public.tblpatients (id, user_id, first_name, second_name, first_lastname, second_lastname, age, gender, phone, notes, active, created_at, updated_at) FROM '$$PATH$$/3473.dat';

--
-- Data for Name: tblproducts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tblproducts (id, name, description, price, stock, image_url, created_at, updated_at, active) FROM stdin;
\.
COPY public.tblproducts (id, name, description, price, stock, image_url, created_at, updated_at, active) FROM '$$PATH$$/3466.dat';

--
-- Data for Name: tblproducts_categories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tblproducts_categories (product_id, category_id, created_at) FROM stdin;
\.
COPY public.tblproducts_categories (product_id, category_id, created_at) FROM '$$PATH$$/3467.dat';

--
-- Data for Name: tblroles; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tblroles (id, rol) FROM stdin;
\.
COPY public.tblroles (id, rol) FROM '$$PATH$$/3469.dat';

--
-- Data for Name: tblusers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tblusers (id, rol_id, username, email, password_hash, code, expiracion, recovery_token, recovery_exp, verified, active, created_at, updated_at) FROM stdin;
\.
COPY public.tblusers (id, rol_id, username, email, password_hash, code, expiracion, recovery_token, recovery_exp, verified, active, created_at, updated_at) FROM '$$PATH$$/3471.dat';

--
-- Name: tblappointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tblappointments_id_seq', 1, false);


--
-- Name: tblauditoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tblauditoria_id_seq', 7, true);


--
-- Name: tblcart_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tblcart_items_id_seq', 1, false);


--
-- Name: tblcarts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tblcarts_id_seq', 1, false);


--
-- Name: tblcategorias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tblcategorias_id_seq', 12, true);


--
-- Name: tblconsultations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tblconsultations_id_seq', 1, false);


--
-- Name: tblpatients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tblpatients_id_seq', 1, false);


--
-- Name: tblproducts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tblproducts_id_seq', 12, true);


--
-- Name: tblroles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tblroles_id_seq', 2, true);


--
-- Name: tblusers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tblusers_id_seq', 3, true);


--
-- Name: tblproducts_categories pk_products_categories; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblproducts_categories
    ADD CONSTRAINT pk_products_categories PRIMARY KEY (product_id, category_id);


--
-- Name: tblappointments tblappointments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblappointments
    ADD CONSTRAINT tblappointments_pkey PRIMARY KEY (id);


--
-- Name: tblauditoria tblauditoria_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblauditoria
    ADD CONSTRAINT tblauditoria_pkey PRIMARY KEY (id);


--
-- Name: tblcart_items tblcart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblcart_items
    ADD CONSTRAINT tblcart_items_pkey PRIMARY KEY (id);


--
-- Name: tblcarts tblcarts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblcarts
    ADD CONSTRAINT tblcarts_pkey PRIMARY KEY (id);


--
-- Name: tblcategories tblcategorias_nombre_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblcategories
    ADD CONSTRAINT tblcategorias_nombre_key UNIQUE (name);


--
-- Name: tblcategories tblcategorias_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblcategories
    ADD CONSTRAINT tblcategorias_pkey PRIMARY KEY (id);


--
-- Name: tblconsultations tblconsultations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblconsultations
    ADD CONSTRAINT tblconsultations_pkey PRIMARY KEY (id);


--
-- Name: tblpatients tblpatients_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblpatients
    ADD CONSTRAINT tblpatients_pkey PRIMARY KEY (id);


--
-- Name: tblproducts tblproducts_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblproducts
    ADD CONSTRAINT tblproducts_name_key UNIQUE (name);


--
-- Name: tblproducts tblproducts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblproducts
    ADD CONSTRAINT tblproducts_pkey PRIMARY KEY (id);


--
-- Name: tblroles tblroles_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblroles
    ADD CONSTRAINT tblroles_pkey PRIMARY KEY (id);


--
-- Name: tblusers tblusers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblusers
    ADD CONSTRAINT tblusers_pkey PRIMARY KEY (id);


--
-- Name: tblusers tblusers_username_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblusers
    ADD CONSTRAINT tblusers_username_key UNIQUE (username);


--
-- Name: idx_auditoria_accion; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_auditoria_accion ON public.tblauditoria USING btree (accion);


--
-- Name: idx_auditoria_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_auditoria_created_at ON public.tblauditoria USING btree (created_at DESC);


--
-- Name: idx_auditoria_tabla; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_auditoria_tabla ON public.tblauditoria USING btree (tabla_afectada);


--
-- Name: idx_auditoria_usuario; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_auditoria_usuario ON public.tblauditoria USING btree (usuario);


--
-- Name: tblappointments fk_appointment_user; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblappointments
    ADD CONSTRAINT fk_appointment_user FOREIGN KEY (user_id) REFERENCES public.tblusers(id) ON DELETE CASCADE;


--
-- Name: tblcarts fk_cart_user; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblcarts
    ADD CONSTRAINT fk_cart_user FOREIGN KEY (user_id) REFERENCES public.tblusers(id) ON DELETE CASCADE;


--
-- Name: tblcart_items fk_cartitem_cart; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblcart_items
    ADD CONSTRAINT fk_cartitem_cart FOREIGN KEY (cart_id) REFERENCES public.tblcarts(id) ON DELETE CASCADE;


--
-- Name: tblcart_items fk_cartitem_product; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblcart_items
    ADD CONSTRAINT fk_cartitem_product FOREIGN KEY (product_id) REFERENCES public.tblproducts(id) ON DELETE CASCADE;


--
-- Name: tblconsultations fk_consultation_patient; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblconsultations
    ADD CONSTRAINT fk_consultation_patient FOREIGN KEY (patient_id) REFERENCES public.tblpatients(id) ON DELETE CASCADE;


--
-- Name: tblpatients fk_patient_user; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblpatients
    ADD CONSTRAINT fk_patient_user FOREIGN KEY (user_id) REFERENCES public.tblusers(id) ON DELETE CASCADE;


--
-- Name: tblproducts_categories fk_pc_category; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblproducts_categories
    ADD CONSTRAINT fk_pc_category FOREIGN KEY (category_id) REFERENCES public.tblcategories(id) ON DELETE CASCADE;


--
-- Name: tblproducts_categories fk_pc_product; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblproducts_categories
    ADD CONSTRAINT fk_pc_product FOREIGN KEY (product_id) REFERENCES public.tblproducts(id) ON DELETE CASCADE;


--
-- Name: tblusers fk_users_roles; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tblusers
    ADD CONSTRAINT fk_users_roles FOREIGN KEY (rol_id) REFERENCES public.tblroles(id);


--
-- Name: DATABASE neondb; Type: ACL; Schema: -; Owner: neondb_owner
--

REVOKE CONNECT,TEMPORARY ON DATABASE neondb FROM PUBLIC;
GRANT ALL ON DATABASE neondb TO neon_superuser;
GRANT CONNECT ON DATABASE neondb TO app_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO app_read;
GRANT USAGE ON SCHEMA public TO app_write;
GRANT USAGE ON SCHEMA public TO app_admin;


--
-- Name: TABLE tblappointments; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT ON TABLE public.tblappointments TO app_read;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tblappointments TO app_write;
GRANT ALL ON TABLE public.tblappointments TO app_admin;


--
-- Name: SEQUENCE tblappointments_id_seq; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT,USAGE ON SEQUENCE public.tblappointments_id_seq TO app_read;
GRANT ALL ON SEQUENCE public.tblappointments_id_seq TO app_write;
GRANT ALL ON SEQUENCE public.tblappointments_id_seq TO app_admin;


--
-- Name: TABLE tblauditoria; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT ON TABLE public.tblauditoria TO app_read;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tblauditoria TO app_write;
GRANT ALL ON TABLE public.tblauditoria TO app_admin;


--
-- Name: SEQUENCE tblauditoria_id_seq; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT,USAGE ON SEQUENCE public.tblauditoria_id_seq TO app_read;
GRANT ALL ON SEQUENCE public.tblauditoria_id_seq TO app_write;
GRANT ALL ON SEQUENCE public.tblauditoria_id_seq TO app_admin;


--
-- Name: TABLE tblcart_items; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT ON TABLE public.tblcart_items TO app_read;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tblcart_items TO app_write;
GRANT ALL ON TABLE public.tblcart_items TO app_admin;


--
-- Name: SEQUENCE tblcart_items_id_seq; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT,USAGE ON SEQUENCE public.tblcart_items_id_seq TO app_read;
GRANT ALL ON SEQUENCE public.tblcart_items_id_seq TO app_write;
GRANT ALL ON SEQUENCE public.tblcart_items_id_seq TO app_admin;


--
-- Name: TABLE tblcarts; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT ON TABLE public.tblcarts TO app_read;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tblcarts TO app_write;
GRANT ALL ON TABLE public.tblcarts TO app_admin;


--
-- Name: SEQUENCE tblcarts_id_seq; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT,USAGE ON SEQUENCE public.tblcarts_id_seq TO app_read;
GRANT ALL ON SEQUENCE public.tblcarts_id_seq TO app_write;
GRANT ALL ON SEQUENCE public.tblcarts_id_seq TO app_admin;


--
-- Name: TABLE tblcategories; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT ON TABLE public.tblcategories TO app_read;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tblcategories TO app_write;
GRANT ALL ON TABLE public.tblcategories TO app_admin;


--
-- Name: SEQUENCE tblcategorias_id_seq; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT,USAGE ON SEQUENCE public.tblcategorias_id_seq TO app_read;
GRANT ALL ON SEQUENCE public.tblcategorias_id_seq TO app_write;
GRANT ALL ON SEQUENCE public.tblcategorias_id_seq TO app_admin;


--
-- Name: TABLE tblconsultations; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT ON TABLE public.tblconsultations TO app_read;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tblconsultations TO app_write;
GRANT ALL ON TABLE public.tblconsultations TO app_admin;


--
-- Name: SEQUENCE tblconsultations_id_seq; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT,USAGE ON SEQUENCE public.tblconsultations_id_seq TO app_read;
GRANT ALL ON SEQUENCE public.tblconsultations_id_seq TO app_write;
GRANT ALL ON SEQUENCE public.tblconsultations_id_seq TO app_admin;


--
-- Name: TABLE tblpatients; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT ON TABLE public.tblpatients TO app_read;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tblpatients TO app_write;
GRANT ALL ON TABLE public.tblpatients TO app_admin;


--
-- Name: SEQUENCE tblpatients_id_seq; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT,USAGE ON SEQUENCE public.tblpatients_id_seq TO app_read;
GRANT ALL ON SEQUENCE public.tblpatients_id_seq TO app_write;
GRANT ALL ON SEQUENCE public.tblpatients_id_seq TO app_admin;


--
-- Name: TABLE tblproducts; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT ON TABLE public.tblproducts TO app_read;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tblproducts TO app_write;
GRANT ALL ON TABLE public.tblproducts TO app_admin;


--
-- Name: TABLE tblproducts_categories; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT ON TABLE public.tblproducts_categories TO app_read;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tblproducts_categories TO app_write;
GRANT ALL ON TABLE public.tblproducts_categories TO app_admin;


--
-- Name: SEQUENCE tblproducts_id_seq; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT,USAGE ON SEQUENCE public.tblproducts_id_seq TO app_read;
GRANT ALL ON SEQUENCE public.tblproducts_id_seq TO app_write;
GRANT ALL ON SEQUENCE public.tblproducts_id_seq TO app_admin;


--
-- Name: TABLE tblroles; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT ON TABLE public.tblroles TO app_read;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tblroles TO app_write;
GRANT ALL ON TABLE public.tblroles TO app_admin;


--
-- Name: SEQUENCE tblroles_id_seq; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT,USAGE ON SEQUENCE public.tblroles_id_seq TO app_read;
GRANT ALL ON SEQUENCE public.tblroles_id_seq TO app_write;
GRANT ALL ON SEQUENCE public.tblroles_id_seq TO app_admin;


--
-- Name: TABLE tblusers; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT ON TABLE public.tblusers TO app_read;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tblusers TO app_write;
GRANT ALL ON TABLE public.tblusers TO app_admin;


--
-- Name: SEQUENCE tblusers_id_seq; Type: ACL; Schema: public; Owner: neondb_owner
--

GRANT SELECT,USAGE ON SEQUENCE public.tblusers_id_seq TO app_read;
GRANT ALL ON SEQUENCE public.tblusers_id_seq TO app_write;
GRANT ALL ON SEQUENCE public.tblusers_id_seq TO app_admin;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: neondb_owner
--

ALTER DEFAULT PRIVILEGES FOR ROLE neondb_owner IN SCHEMA public GRANT SELECT,USAGE ON SEQUENCES TO app_read;
ALTER DEFAULT PRIVILEGES FOR ROLE neondb_owner IN SCHEMA public GRANT ALL ON SEQUENCES TO app_write;
ALTER DEFAULT PRIVILEGES FOR ROLE neondb_owner IN SCHEMA public GRANT ALL ON SEQUENCES TO app_admin;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: neondb_owner
--

ALTER DEFAULT PRIVILEGES FOR ROLE neondb_owner IN SCHEMA public GRANT SELECT ON TABLES TO app_read;
ALTER DEFAULT PRIVILEGES FOR ROLE neondb_owner IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO app_write;
ALTER DEFAULT PRIVILEGES FOR ROLE neondb_owner IN SCHEMA public GRANT ALL ON TABLES TO app_admin;


--
-- PostgreSQL database dump complete
--

